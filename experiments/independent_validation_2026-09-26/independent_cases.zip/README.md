# Independent case review

Status: awaiting an external reviewer. This packet contains no analyzer predictions,
runtime labels, accuracy counts or original descriptive filenames. Do not open
the full repository's benchmark outputs or explanatory results PDF before labeling.
The sources themselves necessarily show their behavior; this is answer masking,
not double blinding or proof of reviewer independence.

Review the 24 cases without executing unknown source. Entry: implementation.
Use 64 integer record IDs 0 through 63, master 92591, 512 input dimensions and
64 output dimensions. The records are distinct. Other context arguments are fixed.
Imported BioHash/KDF/projection functions follow the supplied repository contracts:
generate_key hashes the UTF-8 string biohash:master:domain:index with SHA-256,
then takes the first eight digest bytes as an unsigned little-endian integer.
biohash uses one key for the whole projection; correlated_biohash shares the given
prefix width and uses the private key for the remaining columns. A zero-width
component does not count. Explicit projection concatenation joins component blocks.
For exact finite labels, compare component key labels, not accidental equal output
bits. A runtime audit may be used after an initial manual assessment; record it in
the reason. This is not a claim of actual biometric leakage.

Fill labels.csv. finite_domain_label: reuse_observed, no_reuse_observed, or unsure.
unbounded_scope: fixed, finite_pool, injective_under_contract, or unknown.
State assumptions, reasoning and any counterexample. Reviewer name and UTC date
are required for all entries. Unsure is valid and must not be silently forced to
safe. Do not let the analyzer choose your label. Authors must disclose prior
exposure to predictions and any conflict of interest.

Two reviewers should independently label separate copies. An adjudicator resolves
disagreements only after both copies are frozen and hashed. Retain originals and
adjudication reasons. Report agreement and uncertain cases, not only decided cases.
Add genuinely new cases in a separate package before seeing analyzer outcomes;
provide source, language assumptions, labels and counterexamples. The existing
24 cases are author-written development cases, not an independent holdout.

Return the completed CSV and review notes. Nothing is sent automatically. The
coordinator retains the original-to-neutral ID mapping separately. The independent
review gate remains pending until real external assessments have been received.
